var http = require('http');

var template = 
`   <html> <body> 
	<script type="text/javascript"> 
		    var source = new EventSource("/events/"); 
		    source.onmessage = function(e) { 
		        document.body.innerHTML += e.data + "<br>"; 
		    }; 
    </script> </body> 
    </html>`;

var server = http.createServer( (req,res) => {
    if(req.url.indexOf('events') === -1) {
        res.writeHead(200,{'content-type':'text/html'});
        res.end(template);
    } else {
        req.socket.setTimeout(Number.MAX_VALUE);
	    res.writeHead(200, {
		    'Content-Type': 'text/event-stream', // <- Important headers
		    'Cache-Control': 'no-cache',
		    'Connection': 'keep-alive'
	    });
	res.write('\n');
	(function (clientId) {
		clients[clientId] = res; // <- Add this client to those we consider "attached"
		req.on("close", function () {
			delete clients[clientId];
		}); // <- Remove this client when he disconnects
	})(++clientId);
    }
}).listen(3000);


var clientId = 0;
var clients = {}; // <- Keep a map of attached clients

setInterval(function () {
	var msg = Math.random();
	console.log("Clients: " + Object.keys(clients) + " <- " + msg);
	for (clientId in clients) {
		clients[clientId].write("data: " + msg + "\n\n"); // <- Push a message to a single attached client
	}
}, 2000);

