var http = require('http');

var server = http.createServer( (req,res) => {
    var fs = require('fs');
    var content = fs.readFileSync('./public/index.html');
    res.end(content);
});

var io = require('socket.io')(server);

io.on('connection', function(client) {
	console.log('Client connected...');

    client.on('messages', function(data){
		client.emit('thread', data);
		client.broadcast.emit('thread', data);
	});
});

server.listen(7777);