import { NgModule } from '@angular/core';
import {AboutComponent} from './about.component';
 

@NgModule({
  declarations: [
   
  ],
   
  providers: []
})
export class AboutModule { }
