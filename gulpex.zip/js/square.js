var multiplyMod = require('./multiply');

exports.square = function(x) {

  "use strict";

  return multiplyMod.multiply(x, x);
};