var ShoppingCart = (function(){
    var cart = [];
	function add(item) {
		cart.push(item);
	}

	function get() {
		return cart;
	}

	return {
		add: add,
		get: get
	};
})();